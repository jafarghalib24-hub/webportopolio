/* =========================================================
   Jafar — Freelance Portfolio · script.js
   Lightweight vanilla JS. No dependencies.
   ========================================================= */
(() => {
  'use strict';

  const $  = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const root = document.documentElement;
  const NS = 'http://www.w3.org/2000/svg';

  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer  = matchMedia('(hover: hover) and (pointer: fine)').matches;

  root.classList.add('js');
  if (!reduceMotion) root.classList.add('anim');

  /* ---------- helpers ---------- */
  function svgEl(name, attrs = {}, parent) {
    const el = document.createElementNS(NS, name);
    for (const k in attrs) el.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(el);
    return el;
  }

  /* =========================================================
     1. Split headings into words (for masked text reveal)
     ========================================================= */
  $$('[data-split]').forEach(el => {
    const text = el.textContent.trim();
    el.setAttribute('aria-label', text);
    el.innerHTML = text.split(/\s+/)
      .map((w, i) => `<span class="w" aria-hidden="true"><span style="--d:${i * 70}ms">${w}</span></span>`)
      .join(' ');
  });

  $$('.cal b').forEach((b, i) => b.style.setProperty('--k', i));

  /* =========================================================
     2. Generated SVG webs (hero / CTA / footer)
     ========================================================= */
  function buildWeb(svgTarget, { cx, cy, R, spokes, rings, nodes = 0, minR = .14, animateK = false }) {
    const pt = (a, r) => [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
    let k = 0;

    // spokes
    for (let i = 0; i < spokes; i++) {
      const a = (i / spokes) * Math.PI * 2 - Math.PI / 2;
      const [x, y] = pt(a, R);
      const p = svgEl('path', { d: `M${cx} ${cy}L${x.toFixed(1)} ${y.toFixed(1)}`, class: 'spoke', pathLength: 1 }, svgTarget);
      if (animateK) p.style.setProperty('--k', k++);
    }

    // rings (sagging curves between spokes, like a real web)
    const step = (Math.PI * 2) / spokes;
    for (let r = 1; r <= rings; r++) {
      const rad = R * (minR + (1 - minR) * (r / rings));
      let d = '';
      for (let i = 0; i < spokes; i++) {
        const a0 = (i / spokes) * Math.PI * 2 - Math.PI / 2;
        const [x0, y0] = pt(a0, rad);
        const [cx1, cy1] = pt(a0 + step / 2, rad * Math.cos(step / 2) * .9);
        const [x1, y1] = pt(a0 + step, rad);
        if (i === 0) d += `M${x0.toFixed(1)} ${y0.toFixed(1)}`;
        d += `Q${cx1.toFixed(1)} ${cy1.toFixed(1)} ${x1.toFixed(1)} ${y1.toFixed(1)}`;
      }
      const p = svgEl('path', { d: d + 'Z', class: 'ring' + (r % 3 === 0 ? ' r' : ''), pathLength: 1 }, svgTarget);
      if (animateK) p.style.setProperty('--k', k++);
    }

    // glowing nodes on random intersections
    for (let n = 0; n < nodes; n++) {
      const s = Math.floor(Math.random() * spokes);
      const r = 2 + Math.floor(Math.random() * rings - 1);
      const [x, y] = pt((s / spokes) * Math.PI * 2 - Math.PI / 2, R * (minR + (1 - minR) * (r / rings)));
      const c = svgEl('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 2.6, class: n % 3 === 0 ? 'red' : '' }, svgTarget);
      c.style.setProperty('--nd', (Math.random() * 4).toFixed(2) + 's');
    }
  }

  const heroGroup = $('#webGroup');
  if (heroGroup) buildWeb(heroGroup, { cx: 250, cy: 250, R: 235, spokes: 14, rings: 7, nodes: 18, animateK: true });

  const ctaWeb = $('#ctaWeb');
  if (ctaWeb) {
    buildWeb(ctaWeb, { cx: 200, cy: 200, R: 190, spokes: 12, rings: 6 });
    $$('.ring', ctaWeb).forEach((p, i) => { if ((i + 1) % 3 === 0) p.setAttribute('class', 'ring r'); });
  }

  const footWeb = $('#footWeb');
  if (footWeb) {
    const P = [[8,32],[48,12],[88,42],[128,16],[150,34],[172,16],[212,42],[252,12],[292,32]];
    const links = [[0,1],[1,2],[2,3],[3,4],[4,5],[5,6],[6,7],[7,8],[1,3],[3,5],[5,7],[2,4],[4,6]];
    links.forEach(([a, b], i) => {
      const [x1, y1] = P[a], [x2, y2] = P[b];
      const p = svgEl('path', { d: `M${x1} ${y1}L${x2} ${y2}`, pathLength: 1, class: i % 4 === 0 ? 'r' : '' }, footWeb);
      p.style.setProperty('--k', i);
    });
    P.forEach(([x, y], i) => {
      const c = svgEl('circle', { cx: x, cy: y, r: 2.2 }, footWeb);
      c.style.animationDelay = (i * .35) + 's';
    });
  }

  /* =========================================================
     3. Background: animated network + particles (canvas)
     ========================================================= */
  const canvas = $('#net');
  const ctx = canvas.getContext('2d');
  let W = 0, H = 0, DPR = 1, pts = [];
  const mouse = { x: -9999, y: -9999 };
  let netRunning = false;

  function makePoint() {
    return {
      x: Math.random() * W, y: Math.random() * H,
      vx: (Math.random() - .5) * .28, vy: (Math.random() - .5) * .28,
      r: Math.random() * 1.3 + .5, red: Math.random() < .2
    };
  }

  function resizeNet() {
    DPR = Math.min(window.devicePixelRatio || 1, 1.5);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = W * DPR; canvas.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const count = Math.round(clamp((W * H) / 18000, 26, 85));
    pts = Array.from({ length: count }, makePoint);
    if (reduceMotion) drawNet();
  }

  function drawNet() {
    ctx.clearRect(0, 0, W, H);
    const D = W < 700 ? 105 : 140, D2 = D * D, M = 170, M2 = M * M;

    for (const p of pts) {
      if (!reduceMotion) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < -20) p.x = W + 20; else if (p.x > W + 20) p.x = -20;
        if (p.y < -20) p.y = H + 20; else if (p.y > H + 20) p.y = -20;
      }
    }

    ctx.lineWidth = 1;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      for (let j = i + 1; j < pts.length; j++) {
        const b = pts[j];
        const dx = a.x - b.x, dy = a.y - b.y, d = dx * dx + dy * dy;
        if (d < D2) {
          const alpha = (1 - d / D2) * .2;
          ctx.strokeStyle = (a.red || b.red) ? `rgba(255,45,79,${alpha * 1.3})` : `rgba(169,178,198,${alpha})`;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        }
      }
      // interactive: link to cursor
      const mx = a.x - mouse.x, my = a.y - mouse.y, md = mx * mx + my * my;
      if (md < M2) {
        ctx.strokeStyle = `rgba(255,45,79,${(1 - md / M2) * .45})`;
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mouse.x, mouse.y); ctx.stroke();
      }
    }

    for (const p of pts) {
      ctx.fillStyle = p.red ? 'rgba(255,70,100,.85)' : 'rgba(215,222,238,.6)';
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
    }
  }

  function netLoop() {
    if (!netRunning) return;
    drawNet();
    requestAnimationFrame(netLoop);
  }
  function startNet() { if (reduceMotion || netRunning) return; netRunning = true; requestAnimationFrame(netLoop); }
  function stopNet()  { netRunning = false; }

  resizeNet();
  window.addEventListener('resize', () => { clearTimeout(resizeNet.t); resizeNet.t = setTimeout(() => { resizeNet(); moveIndicator(); }, 150); });
  document.addEventListener('visibilitychange', () => document.hidden ? stopNet() : startNet());
  window.addEventListener('pointermove', e => { mouse.x = e.clientX; mouse.y = e.clientY; }, { passive: true });
  window.addEventListener('pointerleave', () => { mouse.x = mouse.y = -9999; });
  startNet();

  /* =========================================================
     4. Loader
     ========================================================= */
  const loader = $('#loader'), loaderNum = $('#loaderNum'), loaderBar = $('#loaderBar');
  let pageLoaded = document.readyState === 'complete';
  window.addEventListener('load', () => { pageLoaded = true; });
  setTimeout(() => { pageLoaded = true; }, 4000); // safety net (slow fonts)

  const loadStart = performance.now();
  const loadDur = reduceMotion ? 250 : 1700;

  (function loadStep(now) {
    const t = clamp((now - loadStart) / loadDur, 0, 1);
    const eased = 1 - Math.pow(1 - t, 3);
    const val = Math.round(eased * (pageLoaded ? 100 : 92));
    loaderNum.textContent = val;
    loaderBar.style.width = val + '%';
    if (t >= 1 && pageLoaded) return finishLoading();
    requestAnimationFrame(loadStep);
  })(loadStart);

  function finishLoading() {
    loaderNum.textContent = 100; loaderBar.style.width = '100%';
    setTimeout(() => {
      loader.classList.add('done');
      document.body.classList.remove('loading');
      root.classList.add('ready');
      setTimeout(initReveal, reduceMotion ? 0 : 350);
      setTimeout(() => loader.remove(), 1200);
    }, 250);
  }

  /* =========================================================
     5. Scroll-triggered reveals (Intersection Observer)
     ========================================================= */
  function initReveal() {
    const targets = $$('.reveal, [data-split], .tl-item, .skill-grid, .tool-grid, .process, .foot-web');

    if (!('IntersectionObserver' in window) || reduceMotion) {
      targets.forEach(el => el.classList.add('in', 'settled'));
      $$('[data-count]').forEach(el => el.textContent = el.dataset.count);
      return;
    }

    const io = new IntersectionObserver((entries, obs) => {
      entries.forEach(en => {
        if (!en.isIntersecting) return;
        const el = en.target;
        el.classList.add('in');
        if (el.classList.contains('reveal')) setTimeout(() => el.classList.add('settled'), 1800);
        obs.unobserve(el);
      });
    }, { threshold: .15, rootMargin: '0px 0px -6% 0px' });
    targets.forEach(el => io.observe(el));

    // animated counters
    const cio = new IntersectionObserver((entries, obs) => {
      entries.forEach(en => {
        if (!en.isIntersecting) return;
        countUp(en.target);
        obs.unobserve(en.target);
      });
    }, { threshold: .6 });
    $$('[data-count]').forEach(el => cio.observe(el));
  }

  function countUp(el) {
    const end = parseInt(el.dataset.count, 10) || 0;
    const dur = 1500, t0 = performance.now();
    (function tick(now) {
      const t = clamp((now - t0) / dur, 0, 1);
      el.textContent = Math.round((1 - Math.pow(1 - t, 3)) * end);
      if (t < 1) requestAnimationFrame(tick);
    })(t0);
  }

  /* =========================================================
     6. Navbar: sticky state, active section, sliding indicator
     ========================================================= */
  const nav = $('#nav'), navLinks = $('#navLinks'), navInd = $('#navInd'), burger = $('#burger');
  const links = $$('a[data-nav]', navLinks);
  let activeId = 'home';

  function moveIndicator() {
    const a = links.find(l => l.dataset.nav === activeId);
    if (!a || getComputedStyle(navInd).display === 'none') return;
    navInd.style.width = a.offsetWidth + 'px';
    navInd.style.transform = `translateX(${a.offsetLeft}px)`;
    navInd.classList.add('on');
  }

  function setActive(id) {
    // sections without a nav link keep the closest previous link highlighted
    const map = { process: 'skills', why: 'skills' };
    id = map[id] || id;
    if (!links.some(l => l.dataset.nav === id)) return;
    activeId = id;
    links.forEach(l => {
      const on = l.dataset.nav === id;
      l.classList.toggle('active', on);
      if (on) l.setAttribute('aria-current', 'true'); else l.removeAttribute('aria-current');
    });
    moveIndicator();
  }

  if ('IntersectionObserver' in window) {
    const sio = new IntersectionObserver(entries => {
      entries.forEach(en => { if (en.isIntersecting) setActive(en.target.id); });
    }, { rootMargin: '-45% 0px -50% 0px' });
    $$('[data-section]').forEach(s => sio.observe(s));
  }
  setActive('home');
  window.addEventListener('load', moveIndicator);

  function closeMenu() {
    navLinks.classList.remove('open');
    burger.setAttribute('aria-expanded', 'false');
    burger.setAttribute('aria-label', 'Open menu');
  }
  burger.addEventListener('click', () => {
    const open = navLinks.classList.toggle('open');
    burger.setAttribute('aria-expanded', String(open));
    burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });
  links.forEach(l => l.addEventListener('click', closeMenu));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });

  /* =========================================================
     7. Scroll-linked effects (progress, web thread, timeline)
     ========================================================= */
  const progress = $('#progress'), threadFill = $('#threadFill'), threadDot = $('#threadDot');
  const tl = $('#timeline'), tlFill = $('#tlFill');
  const depthEls = $$('[data-depth]');
  const webWrap = $('.web-wrap');
  let scrollY = window.scrollY, ticking = false;

  function onScroll() {
    scrollY = window.scrollY;
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const p = max > 0 ? clamp(scrollY / max, 0, 1) : 0;

    progress.style.transform = `scaleX(${p})`;
    if (threadFill) threadFill.style.strokeDashoffset = 1 - p;
    if (threadDot) threadDot.style.top = (p * 100) + '%';
    nav.classList.toggle('scrolled', scrollY > 30);

    if (tl && tlFill) {
      const r = tl.getBoundingClientRect();
      tlFill.style.height = (clamp((window.innerHeight * .65 - r.top) / r.height, 0, 1) * 100) + '%';
    }
    ticking = false;
  }
  window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
  onScroll();

  /* =========================================================
     8. Parallax + cursor loop
     ========================================================= */
  const cursorDot = $('#cursorDot'), cursorRing = $('#cursorRing');
  let px = window.innerWidth / 2, py = window.innerHeight / 2;   // raw pointer
  let sx = px, sy = py;                                          // smoothed (parallax)
  let rx = px, ry = py;                                          // ring

  window.addEventListener('pointermove', e => { px = e.clientX; py = e.clientY; }, { passive: true });

  if (finePointer && !reduceMotion) {
    root.classList.add('has-cursor');
    document.addEventListener('mouseover', e => {
      cursorRing.classList.toggle('hot', !!e.target.closest('a, button, .project-card, .tool, .mini, .value'));
    });
  }

  function frame() {
    // smooth pointer
    sx += (px - sx) * .06; sy += (py - sy) * .06;
    rx += (px - rx) * .18; ry += (py - ry) * .18;

    if (root.classList.contains('has-cursor')) {
      cursorDot.style.transform = `translate3d(${px}px, ${py}px, 0)`;
      cursorRing.style.transform = `translate3d(${rx}px, ${ry}px, 0)`;
    }

    // hero parallax only while hero is (roughly) visible
    if (scrollY < window.innerHeight * 1.4) {
      const nx = (sx / window.innerWidth - .5) * 2;   // -1..1
      const ny = (sy / window.innerHeight - .5) * 2;
      depthEls.forEach(el => {
        const depth = parseFloat(el.dataset.depth) || 0;
        const m = finePointer ? (parseFloat(el.dataset.mouse) || 0) : 0;
        const tx = nx * m, ty = scrollY * depth + ny * m;
        el.style.transform = `translate3d(${tx.toFixed(1)}px, ${ty.toFixed(1)}px, 0)`
          + (el === webWrap ? ` rotate(${(scrollY * .035).toFixed(2)}deg)` : '');
      });
    }
    requestAnimationFrame(frame);
  }
  if (!reduceMotion) requestAnimationFrame(frame);

  /* =========================================================
     9. Card spotlight + subtle 3D tilt
     ========================================================= */
  if (finePointer) {
    document.addEventListener('pointermove', e => {
      const card = e.target.closest && e.target.closest('.spot');
      if (!card) return;
      const r = card.getBoundingClientRect();
      card.style.setProperty('--mx', (e.clientX - r.left) + 'px');
      card.style.setProperty('--my', (e.clientY - r.top) + 'px');
    }, { passive: true });

    if (!reduceMotion) {
      $$('.project-card').forEach(card => {
        card.addEventListener('pointermove', e => {
          const r = card.getBoundingClientRect();
          const x = (e.clientX - r.left) / r.width - .5;
          const y = (e.clientY - r.top) / r.height - .5;
          card.style.transform = `perspective(1100px) rotateX(${(-y * 4).toFixed(2)}deg) rotateY(${(x * 5).toFixed(2)}deg) translateY(-6px)`;
        });
        card.addEventListener('pointerleave', () => { card.style.transform = ''; });
      });
    }
  }

  /* =========================================================
     10. Screenshot slots — auto-swap mockup for real image
     ========================================================= */
  $$('.preview[data-shot]').forEach(pv => {
    const img = $('.shot', pv);
    if (!img) return;
    const check = () => { if (img.naturalWidth > 0) pv.classList.add('has-shot'); };
    if (img.complete) check();
    img.addEventListener('load', check);
  });

  /* =========================================================
     11. Placeholder links → friendly toast
     ========================================================= */
  const toast = $('#toast');
  let toastTimer;
  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
  }
  document.addEventListener('click', e => {
    const a = e.target.closest('main a[href]');
    if (!a) return;
    const href = a.getAttribute('href');
    if (href === '#' || href.includes('your-profile') || href.includes('your.email@example.com')) {
      e.preventDefault();
      showToast('Link belum diisi — ganti href di index.html dengan link asli kamu.');
    }
  });

})();
